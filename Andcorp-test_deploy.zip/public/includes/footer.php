<footer class="py-4" style="background: var(--primary); color: white; margin-top: auto;">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <p class="mb-2">&copy; <?php echo date('Y'); ?> <a href="https://andcorpautos.com" target="_blank" style="color: white; text-decoration: none;">Andcorp Autos</a>. All rights reserved.</p>
                <p class="mb-0 small">
                    Contact: <a href="mailto:info@andcorpautos.com" style="color: white; text-decoration: none;">info@andcorpautos.com</a> | 
                    <a href="tel:+233249494091" style="color: white; text-decoration: none;">+233 24 949 4091</a>
                </p>
            </div>
        </div>
    </div>
</footer>

